<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    use HasFactory;
    protected $fillable = [
        'persona_id', 'dni', 'persona_nombre', 'fecha_alta', 'sexo', 'fecha_nacimiento', 'segmento', 'sucursal'
    ];
}
