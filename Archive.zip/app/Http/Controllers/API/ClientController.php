<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\API\BaseController as BaseController;
use App\Models\Client;
use Illuminate\Http\Request;
use Validator;

class ClientController extends BaseController
{
    public function index(Request $request)
    {    
        $client = Client::all();

        return $this->sendResponse($client, 'Clients retrieved successfully.');
    }


   

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'persona_id' => 'required|unique:clients',
            'dni' => 'required',
            'persona_nombre' => 'required',
            'fecha_alta' => 'required',
            'sexo' => 'required',
            'fecha_nacimiento' => 'required',
            'segmento' => 'required',
            'sucursal' => 'required'
        ]);

        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }

        $input = $request->all();
        $client = Client::create($input);

        return $this->sendResponse($client, 'Client create successfully.');
    }

    public function destroy($id)
    {
        
    }

}
